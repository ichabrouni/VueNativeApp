<template>
    <view class ="picture">
        <canvas class="canvas" > </canvas>
        <text>hellp</text>
    </view>
</template>

<script>
     
     export default {
     name: 'picture'
     }


</script>

<style land="scss" scoped>
    .picture{
        display: block;
        width: 100vw;
        height: 100vh;

        padding: 25px;
        box-shadow: border-box;
        
            
    }
    .canvas {
            display: block;
            width: 100%;
            max-width: 1200px;

            margin: 0 auto;

            box-shadow: 4px 4px 12px 0px transparent
    }
</style>