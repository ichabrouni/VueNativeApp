<template>
    <view class="container">
        <view class="statusbar"> </view>
        <touchable-opacity :on-press="getLocation">
      <text class="getloc">Get Location</text>
    </touchable-opacity>
    <text class="loc">Location Object:</text>
    <text> {{ location }}</text>
    <text class="lati">Latitude Only:</text>
    <text>{{ latitude }}</text>

    <text class="text-error">{{ errorMessage }}</text>
      <text class="text-color-primary">GPS</text>
       
    </view>
</template>

<script>
import * as Location from "expo-location";
import * as Permissions from "expo-permissions";

export default {
  data: function() {
    return {
      location: "",
      latitude: "",
      errorMessage: ""
    };
  },
  methods: {
    getLocation: function() {
      Permissions.askAsync(Permissions.LOCATION_FOREGROUND)
        .then(status => {
          if (!status.granted) {
            this.errorMessage = "Permission to access location was denied";
          } else if (status.granted) {
            Location.getCurrentPositionAsync({}).then(location => {
              this.location = location;
              this.latitude = location.coords.latitude
              this.errorMessage = "";
            });
          }
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>

<style>

.container {
  background-color: rgb(57, 180, 218);
  align-items: center;
  justify-content: center;
  flex: 1;
}

.getloc{
  position: absolute;
  top: -120px;
  left: -70px;
  font-size: 22;
  padding: 9px;
  background-color: rgb(4, 4, 85);
  color: blanchedalmond;
  
}


.text-color-primary {
  color: blue;
}
.statusbar{
  background-color: rgb(189, 171, 8);
  height: 30px;
}
.text-color-primary {
  color: rgb(231, 245, 170);
  padding: 50px;
  font-size: 47;
  font-weight: 600;
  font-style: italic;
  position: absolute;
  top:40
}
</style>