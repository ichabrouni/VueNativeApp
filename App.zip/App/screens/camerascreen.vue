<template>
    <view class="container">
        <view class="statusbar"></view>
        <text class="text-color-primary">CAMERA VIEW</text>
        
       <camera class="container1" :type="type" ref="Webcam"/>
       
  
         <touchable-opacity :on-press="Switch">
           
           <text class="switch">Switch</text>
      
    </touchable-opacity>
    
          <touchable-opacity :on-press="capture">
            <text class="capture">Capture </text>
      
    </touchable-opacity>
      
    
    </view>
     
</template>

<script>
import * as Permissions from 'expo-permissions';
import { Camera } from 'expo-camera';


export default {
 data: function() {
   return {
     hasCameraPermission: false,
     type: Camera.Constants.Type.back,
   };
 },
 mounted: function() {
   Permissions.askAsync(Permissions.CAMERA)
     .then(status => {
       hasCameraPermission = status.status == "granted" ? true : false;
     }).catch((err)=>{
        console.log(err);
     });  
 },

 methods: {
   Switch(){
    this.type = this.type == Camera.Constants.Type.back ? Camera.Constants.Type.front : Camera.Constants.Type.back;
   },
capture() {
  this.$refs.Webcam.takePictureAsync().then(
    function(CamPic) {
      console.log(CamPic)
    }
  )
  alert("Image Saved!")
  }
 },

 components: { Camera },
             
};

</script>


<style>
.container {
  background-color: rgb(118, 6, 133);
  align-items: center;
  justify-content: center;
  flex: 2;
}

.container1 {
  flex: 1;
  width: 350px;
  height: 225px;
  position: absolute;
  top: 150px;
  border-width: 3px;
  border-color: rgb(228, 218, 184);

}

.switch{
  position: absolute;
  top: 90px;
  left: -60px;
  align-items: center;
  justify-content: center;
  font-size: 35;
  color:rgb(228, 218, 184);
  margin: 10px;
}

.capture{
  position: absolute;
  top: 30px;
  left: -70px;
  align-items: center;
  justify-content: center;
  font-size: 35;
  color: rgb(228, 218, 184);
  margin: 10px;
  
}
.statusbar{
  background-color: blue;
}
.text-color-primary {
  color: rgb(231, 245, 170);
  padding: 50px;
  font-size: 28;
  font-weight: 500;
  font-style: italic;
  position: absolute;
  top:40
}
.text-color-primary1 {
  color: rgb(231, 245, 170);
  padding: 50px;
  font-size: 30;
  font-weight: 400;
  font-style: italic;
  position: absolute;
  top:350
}
.text-color-primary2 {
  color: rgb(231, 245, 170);
  padding: 50px;
  font-size: 30;
  font-weight: 400;
  font-style: italic;
  position: absolute;
  top:410;
}
</style>