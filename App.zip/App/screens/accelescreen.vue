<template>
    <view class="container">
    <touchable-opacity class="button" :on-press="Show">
            <text>Accelerometer </text>
      
    </touchable-opacity>
       
       <text>x:{{accelerometerData.x}}</text>
       <text>y:{{accelerometerData.y}}</text>
        <text>z:{{accelerometerData.z}}</text> 
    </view>
     
</template>

<script>

import {Accelerometer} from "expo-sensors";

export default{
    data(){
        return{
            accelerometerData: {},
        };
    },
    props:{
        navigation: {
            type: Object
        },
    },
    methods: {
        Show(){
            Accelerometer.addListener(accelerometerData => {
                this.accelerometerData = accelerometerData;
                            
            });
            Accelerometer.setUpdateInterval(1000);
        }
    }
        };
</script>


<style>
.container {
  background-color: rgb(118, 6, 133);
  align-items: center;
  justify-content: center;
  flex: 2;
   padding: 10px;  
}

</style>