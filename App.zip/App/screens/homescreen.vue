<template>
  
<view class="container">
  
   

    
   
    <text class="crypto">LAB-I</text>
    <text class="crypto1">IELY Chabrouni</text>

    
   
      <touchable-opacity :on-press="gotoaccele" ><text class="text-color-primary1">1- Accelerometer</text></touchable-opacity>
      <touchable-opacity :on-press="gotogps" > <text class="text-color-primary2"> 2- GPS</text></touchable-opacity>
      <touchable-opacity :on-press="gotocamera" ><text class="text-color-primary3" >3- Camera</text></touchable-opacity>
      
      
  </view>
 
</template>

<style>


.container {
  background-color: rgb(118, 6, 133);
  align-items: center;
  justify-content: center;
  flex: 1;
  flex-direction: column;
}

.crypto{
  position:absolute;
  top: 90px;
  background-color: #ECFFAE;
  border-width: 3px;
  border-color: blue;
  

  font-family: PTSans-CaptionBold;
  font-size: 40px;
  color: #8500C7;
  text-align: center;
  padding: 5px;
}
.crypto1{
  font-size: 30;
  position: absolute;
  top: 170px;
  color: rgb(193, 238, 135);
  
}

.statubar{
  background-color: blue;
  height: 40px;
}
.text-color-primary {
  color: rgb(255, 255, 255);
  padding: 10px;
  font-size: 47;
  border-width: 1;
  border-color: rgb(178, 218, 138);
  position: absolute;
  top:220px;

}

.text-color-primary1 {
  color: rgb(255, 255, 255);
  padding: 10px;
  font-size: 22;
}
.text-color-primary3 {
  color: rgb(255, 255, 255);
  padding: 10px;
  font-size: 22;
  position: absolute;
  top: 70px;
  left: -92px;
}

.text-color-primary2 {
  color: rgb(255, 255, 255);
  padding: 10px;
  font-size: 22;
  margin: 10px;
  position: absolute;
  left: -107px;
  
}
</style>


<script>
export default{
  props: {
    navigation:{
      type: Object
    },
  },
    component:{

    },
    data(){
      return{

      }
    },

    methods:{
      gotocamera(){
        this.navigation.navigate('Camera')

      },
      gotogps(){
        this.navigation.navigate('Gps')
      },

      gotoaccele(){
        this.navigation.navigate('Accele')
      }
      
         
    }
}

</script>
